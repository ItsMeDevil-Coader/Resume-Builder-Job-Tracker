Complete Resume Builder + Job Tracker (Java + SQLite)

How to run:
1. Install JDK 17+ and Maven.
2. Unzip the project.
3. Create the database tables by running the SQL script:
   - sqlite3 resumebuilder.db < sql/schema.sql
   (or you can let the app create DB file and tables will be created manually once)
4. Build package:
   mvn clean package
   (this creates a jar-with-dependencies under target/)
5. Run:
   java -jar target/resume-job-tracker-complete-1.0-SNAPSHOT-jar-with-dependencies.jar
6. The app will run in console and store/read resumebuilder.db in the project root.

Files included:
- pom.xml
- sql/schema.sql
- src/main/java/... (DBConnection, models, DAOs, Main, util)

If you want, I can:
- Make the app auto-create the DB file and run schema at startup.
- Add user authentication and passwords.
- Convert to a GUI or web app.
