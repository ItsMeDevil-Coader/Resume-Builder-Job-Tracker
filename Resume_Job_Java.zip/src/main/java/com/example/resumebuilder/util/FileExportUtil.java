package com.example.resumebuilder.util;

import com.example.resumebuilder.model.Resume;
import com.example.resumebuilder.model.User;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FileExportUtil {
    public static Path exportResumeToText(User user, Resume resume) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("Name: ").append(user.getName()).append('\n');
        sb.append("Email: ").append(user.getEmail()).append('\n');
        sb.append("Phone: ").append(user.getPhone()).append('\n').append('\n');
        sb.append("SUMMARY\n").append(resume.getSummary()).append('\n').append('\n');
        sb.append("EDUCATION\n").append(resume.getEducation()).append('\n').append('\n');
        sb.append("EXPERIENCE\n").append(resume.getExperience()).append('\n').append('\n');
        sb.append("SKILLS\n").append(resume.getSkills()).append('\n');

        Path out = Path.of("resume_" + user.getId() + ".txt");
        return Files.writeString(out, sb.toString());
    }
}
