package com.example.resumebuilder;

import com.example.resumebuilder.dao.JobDAO;
import com.example.resumebuilder.dao.ResumeDAO;
import com.example.resumebuilder.dao.UserDAO;
import com.example.resumebuilder.db.DBConnection;
import com.example.resumebuilder.model.JobApplication;
import com.example.resumebuilder.model.Resume;
import com.example.resumebuilder.model.User;
import com.example.resumebuilder.util.FileExportUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        // ensure tables exist (run schema.sql if not present)
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement()) {
            // attempt to create tables if not exist
            String schema = new String(Main.class.getResourceAsStream("/../../sql/schema.sql").readAllBytes());
            // ignored — recommend running sql/schema.sql manually before first run
        } catch (Exception e) {
            // ignore; instruct user to run sql/schema.sql before running
        }

        UserDAO userDAO = new UserDAO();
        ResumeDAO resumeDAO = new ResumeDAO();
        JobDAO jobDAO = new JobDAO();

        System.out.println("--- Resume Builder + Job Tracker ---");
        System.out.print("Enter your email (used as account): ");
        String email = scanner.nextLine().trim();
        User user = userDAO.findByEmail(email);
        if (user == null) {
            System.out.print("No account found. Enter your name: ");
            String name = scanner.nextLine().trim();
            System.out.print("Phone (optional): ");
            String phone = scanner.nextLine().trim();
            user = new User(name, email, phone);
            userDAO.create(user);
            System.out.println("User created with ID: " + user.getId());
        } else {
            System.out.println("Welcome back, " + user.getName());
        }

        while (true) {
            System.out.println("\nMenu: 1) Edit Resume 2) View Resume 3) Export Resume 4) Add Job Application 5) List Applications 6) Update Application Status 0) Exit");
            System.out.print("Choice: ");
            String c = scanner.nextLine().trim();
            switch (c) {
                case "1":
                    editResume(user, resumeDAO);
                    break;
                case "2":
                    viewResume(user, resumeDAO);
                    break;
                case "3":
                    exportResume(user, resumeDAO);
                    break;
                case "4":
                    addJob(user, jobDAO);
                    break;
                case "5":
                    listJobs(user, jobDAO);
                    break;
                case "6":
                    updateJobStatus(jobDAO);
                    break;
                case "0":
                    System.out.println("Bye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private static void editResume(User user, ResumeDAO resumeDAO) throws SQLException {
        Resume r = resumeDAO.findByUserId(user.getId());
        if (r == null) r = new Resume();
        r.setUserId(user.getId());
        System.out.println("Enter summary (single line): ");
        r.setSummary(scanner.nextLine().trim());
        System.out.println("Enter education (multi-line; end with a single '.' on a new line): ");
        r.setEducation(readMultiline());
        System.out.println("Enter experience (multi-line; end with a single '.' on a new line): ");
        r.setExperience(readMultiline());
        System.out.println("Enter skills (comma separated): ");
        r.setSkills(scanner.nextLine().trim());
        resumeDAO.upsert(r);
        System.out.println("Resume saved.");
    }

    private static String readMultiline() {
        StringBuilder sb = new StringBuilder();
        while (true) {
            String line = scanner.nextLine();
            if (".".equals(line.trim())) break;
            sb.append(line).append('\n');
        }
        return sb.toString().trim();
    }

    private static void viewResume(User user, ResumeDAO resumeDAO) throws SQLException {
        Resume r = resumeDAO.findByUserId(user.getId());
        if (r == null) {
            System.out.println("No resume found. Create one first.");
            return;
        }
        System.out.println("--- Resume for " + user.getName() + " ---");
        System.out.println("Summary:\n" + r.getSummary());
        System.out.println("Education:\n" + r.getEducation());
        System.out.println("Experience:\n" + r.getExperience());
        System.out.println("Skills: " + r.getSkills());
    }

    private static void exportResume(User user, ResumeDAO resumeDAO) throws Exception {
        Resume r = resumeDAO.findByUserId(user.getId());
        if (r == null) { System.out.println("No resume to export."); return; }
        var path = FileExportUtil.exportResumeToText(user, r);
        System.out.println("Resume exported to: " + path.toAbsolutePath());
    }

    private static void addJob(User user, JobDAO jobDAO) throws SQLException {
        JobApplication j = new JobApplication();
        j.setUserId(user.getId());
        System.out.print("Company: "); j.setCompany(scanner.nextLine().trim());
        System.out.print("Role: "); j.setRole(scanner.nextLine().trim());
        j.setAppliedDate(LocalDate.now().toString());
        System.out.print("Status (Applied/Interview/Offer/Rejected): "); j.setStatus(scanner.nextLine().trim());
        System.out.print("Notes: "); j.setNotes(scanner.nextLine().trim());
        jobDAO.add(j);
        System.out.println("Job application added.");
    }

    private static void listJobs(User user, JobDAO jobDAO) throws SQLException {
        List<JobApplication> list = jobDAO.listByUser(user.getId());
        if (list.isEmpty()) System.out.println("No applications found.");
        for (var j : list) {
            System.out.println("ID:" + j.getId() + " | " + j.getCompany() + " - " + j.getRole() + " | " + j.getAppliedDate() + " | " + j.getStatus());
            System.out.println("Notes: " + j.getNotes());
        }
    }

    private static void updateJobStatus(JobDAO jobDAO) throws SQLException {
        System.out.print("Enter application ID: ");
        int id = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("New status: ");
        String status = scanner.nextLine().trim();
        jobDAO.updateStatus(id, status);
        System.out.println("Status updated.");
    }
}
