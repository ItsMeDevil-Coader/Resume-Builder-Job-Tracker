package com.example.resumebuilder.dao;

import com.example.resumebuilder.db.DBConnection;
import com.example.resumebuilder.model.Resume;

import java.sql.*;

public class ResumeDAO {
    public void upsert(Resume r) throws SQLException {
        String select = "SELECT id FROM resumes WHERE user_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(select)){
            ps.setInt(1, r.getUserId());
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String upd = "UPDATE resumes SET summary=?,education=?,experience=?,skills=? WHERE id=?";
                    try (PreparedStatement u = c.prepareStatement(upd)){
                        u.setString(1, r.getSummary());
                        u.setString(2, r.getEducation());
                        u.setString(3, r.getExperience());
                        u.setString(4, r.getSkills());
                        u.setInt(5, id);
                        u.executeUpdate();
                    }
                } else {
                    String ins = "INSERT INTO resumes(user_id,summary,education,experience,skills) VALUES(?,?,?,?,?)";
                    try (PreparedStatement i = c.prepareStatement(ins)){
                        i.setInt(1, r.getUserId());
                        i.setString(2, r.getSummary());
                        i.setString(3, r.getEducation());
                        i.setString(4, r.getExperience());
                        i.setString(5, r.getSkills());
                        i.executeUpdate();
                    }
                }
            }
        }
    }

    public Resume findByUserId(int userId) throws SQLException {
        String sql = "SELECT id,user_id,summary,education,experience,skills FROM resumes WHERE user_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()){
                    Resume r = new Resume();
                    r.setId(rs.getInt("id"));
                    r.setUserId(rs.getInt("user_id"));
                    r.setSummary(rs.getString("summary"));
                    r.setEducation(rs.getString("education"));
                    r.setExperience(rs.getString("experience"));
                    r.setSkills(rs.getString("skills"));
                    return r;
                }
            }
        }
        return null;
    }
}
