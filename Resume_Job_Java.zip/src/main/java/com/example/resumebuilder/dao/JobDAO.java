package com.example.resumebuilder.dao;

import com.example.resumebuilder.db.DBConnection;
import com.example.resumebuilder.model.JobApplication;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobDAO {
    public void add(JobApplication j) throws SQLException {
        String sql = "INSERT INTO job_applications(user_id,company,role,applied_date,status,notes) VALUES(?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, j.getUserId());
            ps.setString(2, j.getCompany());
            ps.setString(3, j.getRole());
            ps.setString(4, j.getAppliedDate());
            ps.setString(5, j.getStatus());
            ps.setString(6, j.getNotes());
            ps.executeUpdate();
        }
    }

    public List<JobApplication> listByUser(int userId) throws SQLException {
        String sql = "SELECT id,user_id,company,role,applied_date,status,notes FROM job_applications WHERE user_id = ? ORDER BY applied_date DESC";
        List<JobApplication> out = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    JobApplication j = new JobApplication();
                    j.setId(rs.getInt("id"));
                    j.setUserId(rs.getInt("user_id"));
                    j.setCompany(rs.getString("company"));
                    j.setRole(rs.getString("role"));
                    j.setAppliedDate(rs.getString("applied_date"));
                    j.setStatus(rs.getString("status"));
                    j.setNotes(rs.getString("notes"));
                    out.add(j);
                }
            }
        }
        return out;
    }

    public void updateStatus(int id, String status) throws SQLException {
        String sql = "UPDATE job_applications SET status = ? WHERE id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }
}
