package com.example.resumebuilder.dao;

import com.example.resumebuilder.db.DBConnection;
import com.example.resumebuilder.model.User;

import java.sql.*;

public class UserDAO {
    public User create(User user) throws SQLException {
        String sql = "INSERT INTO users(name,email,phone) VALUES(?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) user.setId(rs.getInt(1));
            }
        }
        return user;
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT id,name,email,phone FROM users WHERE email = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)){
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()) {
                    return new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("phone"));
                }
            }
        }
        return null;
    }
}
